


$(document).ready(function () {
    $('.status-dropdown').on('change', function () {
        $('.search-form').submit();
    });
});